# Image Resizer

Resize the 'jpg' images in high quality

use the following url:
http://localhost:3000/images?filename={desired_file}&height={desired_height}&width={desired_width}

Note:

you should put your image in the images folder first
the {desired_height} & {desired_width} must be positive numbers, unless that you will get "status-404"
